﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace COS_210
{
    public partial class UserMain : Form
    {
        public UserMain()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\htoot\OneDrive\Documents\Gymdb.mdf;Integrated Security=True;Connect Timeout=30");

        private void label11_Click(object sender, EventArgs e)
        {
            // Log Ou button
            Login log = new Login();
            this.Hide();
            log.Show();
        }

        int i = 0;
        private void classDG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            i = Convert.ToInt32(classDG.SelectedRows[0].Cells[0].Value.ToString());
            eid.Text = classDG.SelectedRows[0].Cells[1].Value.ToString();
           
        }
        private void classdata()
        {
            // Conncet the data grid view and the Class Table
            con.Open();
            string query = "select * from classTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            classDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void enrolldata()
        {
            // Connect the data grid view and the Enroll Table
            con.Open();
            string query = "select * from enrollTable ";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            eDG.DataSource = ds.Tables[0];
            con.Close();
        }


        private void UserMain_Load(object sender, EventArgs e)
        {

            classdata(); 
            enrolldata();
        }
 
        private void memberDG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e) // Enroll Button
        {
            if (eid.Text == "" || ename.Text == "" )
            {
                MessageBox.Show("Missing Info");


            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into enrollTable values ('" + eid.Text + "','" + ename.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Enrolled Successfully");
                    con.Close();
                    enrolldata();
                
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        int key = 0;

        private void eDG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            key = Convert.ToInt32(eDG.SelectedRows[0].Cells[0].Value.ToString());
            eid.Text = eDG.SelectedRows[0].Cells[1].Value.ToString();
            ename.Text = eDG.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void label8_Click(object sender, EventArgs e) // Refresh Button
        {
            classdata();
            enrolldata();
            search.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void ccat_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void filterbyname() // Search with class category
        {
            con.Open();
            string query = "select * from classTable where ccategory='" + search.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            classDG.DataSource = ds.Tables[0];
            con.Close();
        }

        private void search_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e) // Search Button
        {
            filterbyname();
        }

        private void button4_Click(object sender, EventArgs e)
        {
    
        }

        private void button3_Click(object sender, EventArgs e) // Cancel Enrroll
        {
            if (key == 0)
            {
                MessageBox.Show("Select Enrolled Class to Cancel");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from enrollTable where eid = " + key + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Enrolled Class Cancelled");
                    ename.Text = "";
                    eid.Text = "";
                   
                    con.Close();
                    enrolldata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e) // Clear Button
        {
            ename.Text = "";
            eid.Text = "";
        }

        private void ename_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

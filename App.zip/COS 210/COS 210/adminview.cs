﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COS_210
{
    public partial class adminview : Form
    {
        public adminview()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e) 
        {
            AdminMain log = new AdminMain();
            this.Hide();
            log.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\htoot\OneDrive\Documents\Gymdb.mdf;Integrated Security=True;Connect Timeout=30");
        private void admindata() // Connec to admin Table
        {
            con.Open();
            string query = "select * from adminTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            adminDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void filterbyname() // Search by admin name
        {
            con.Open();
            string query = "select * from adminTable where aname='" + searchaname.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            adminDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void adminview_Load(object sender, EventArgs e)
        {
            admindata();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            admindata();
        }

        private void searchadmin_Click(object sender, EventArgs e) // Search Button
        {
            filterbyname();
            searchaname.Text = "";
        }

        private void button3_Click(object sender, EventArgs e) // Clear Button
        {
            aname.Text = "";
            apass.Text = "";
        }

        private void button5_Click(object sender, EventArgs e) // Add admin
        {
            if (aname.Text == "" || apass.Text == "" )
            {
                MessageBox.Show("Please Fill All the Boxes");


            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into adminTable values ('" + aname.Text + "','" + apass.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Admin Added Successfully");
                    aname.Text = "";
                    apass.Text = "";
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        int key = 0;
        private void adminDG_CellContentClick(object sender, DataGridViewCellEventArgs e) // Click cell auto insert Values
        {

            key = Convert.ToInt32(adminDG.SelectedRows[0].Cells[0].Value.ToString());
            aname.Text = adminDG.SelectedRows[0].Cells[1].Value.ToString();
            apass.Text = adminDG.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e) // Delete Admin
        {
            if (key == 0)
            {
                MessageBox.Show("Select Admin to Delete");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from adminTable where aid = " + key + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Admin Deleted");
                    aname.Text = "";
                    apass.Text = "";
                    con.Close();
                    admindata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e) //Update Admin
        {

            if (key == 0 || aname.Text == "" || apass.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update adminTable set aname='" + aname.Text + "',apw='" +apass.Text + "' where aid=" + key + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Admin Updated");
                    con.Close();
                    admindata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}

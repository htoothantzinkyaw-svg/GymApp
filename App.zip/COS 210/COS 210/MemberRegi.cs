﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace COS_210
{
    public partial class MemberRegi : Form
    {
        public MemberRegi()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            // Back button on the top left coner of the form ( Go back to Login Form )
            Login log = new Login();
            this.Hide();
            log.Show();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\htoot\OneDrive\Documents\Gymdb.mdf;Integrated Security=True;Connect Timeout=30");
        private void MemberRegi_Load(object sender, EventArgs e)
        {
            
        }


        Regex ph = new Regex(@"^[0-9]+$"); // Numbers Validation

        string email = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$"; // Email Validation
        private void button1_Click(object sender, EventArgs e) // Register Button
        {
            // If user left blank boxes
            if (mname.Text == ""||mgender.Text =="" || mage.Text == "" || mphno.Text == ""||msession.Text=="" || mfee.Text == "" || mpw.Text == ""|| mconpw.Text=="" || mgmail.Text == "")
            {
                MessageBox.Show("Please Fill All the Boxes");

             
            }
            else
            {
                try
                {
                    con.Open();
                    // Add Data To memberTable
                    string query = "insert into memberTable values ('"+ mname.Text +"','"+ mgender.SelectedItem.ToString()+"','"+ mage.Text +"','"+ mphno.Text +"','"+ msession.SelectedItem.ToString()+"','"+ mfee.Text +"','"+ mpw.Text +"','"+ mgmail.Text +"')";

                    if (mconpw.Text != mpw.Text) // Password and Confirm Password are equal or not - Validation
                    {
                        MessageBox.Show(this.mconpw, "Do you not see Confirm Password ? (-_-) ");
                    }

                    else if(mphno.TextLength<10) // Phone Number Length must not be less than 10 - Validation
                    {
                        MessageBox.Show(this.mphno,"Do you think I add the note under the Ph.No just for fun ? ");
                    }

                    else if (!ph.IsMatch(mphno.Text)) // No Letters is allowed in Phone Number - Validation
                    {
                        MessageBox.Show(this.mphno, "Oh my God.... NO LETTERS IN PHONE NUMBERS !!! ");
                    }

                    else if (!ph.IsMatch(mage.Text)) // No letters is allowed in Age - Validation
                    {
                        MessageBox.Show(this.mage, " No Letter in Age. Are you kidding me ? !!! ");
                    }

                    else if(mage.TextLength>=3) // Age must not be equal or more than 3 digit - Validation
                    {
                        MessageBox.Show(this.mage," Are you joking ? Write your actual age ");
                    }

                    else if (!ph.IsMatch(mfee.Text)) // No Letters is allowed in Monthly Fee - Validation
                    {
                        MessageBox.Show(this.mfee, " Bruh... Who type letters in Monthly Amount ? Please have COMMON SENSE !!! ");
                    }

                    else if(!Regex.IsMatch(mgmail.Text,email)) // Email Format Validation
                    {
                        MessageBox.Show(this.mgmail, " Can't you see the error icon on the right side on Gmail ? ");
                    }

                    else
                    {
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Registered Successfully . Hope you get the body type you want <3 ");
                    }
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void button2_Click(object sender, EventArgs e) // Reset Button
        {
            mname.Text = "";
            mgender.Text = "Select Gender";
            mage.Text = "";
            mphno.Text = "";
            msession.Text = "Select Session";
            mfee.Text = "";
            mpw.Text = "";
            mconpw.Text = "";
            mgmail.Text = "";


        }
        
        // Error Provider Codes
        private void mphno_TextChanged(object sender, EventArgs e)
        {
          if(ph.IsMatch(mphno.Text))
          {
             errorProvider2.Clear();
          }
          else
          {
             errorProvider2.SetError(this.mphno, "Invalid Ph.No");
          }
        }

       
        private void mage_TextChanged(object sender, EventArgs e)
        {
            if (ph.IsMatch(mage.Text))
            {
                errorProvider3.Clear();
            }
            else
            {
                errorProvider3.SetError(this.mage, "Invalid Age");
            }

        }

        private void mfee_TextChanged(object sender, EventArgs e)
        {
            if (ph.IsMatch(mfee.Text))
            {
                errorProvider4.Clear();
            }
            else
            {
                errorProvider4.SetError(this.mfee, "Fee should be only numbers");
            }
        }
        
        private void mgmail_TextChanged(object sender, EventArgs e)
        {
            if(Regex.IsMatch(mgmail.Text,email))
            {
                errorProvider5.Clear();
            }
            else
            {
                errorProvider5.SetError(this.mgmail, "Invalid Email Format !!!");
                
            }

        }
        private void mconpw_TextChanged(object sender, EventArgs e)
        {
            if (mconpw.Text != mpw.Text )
            {
                errorProvider1.SetError(this.mconpw, "Password Mismatch !!!");
            }
            else
            {
                errorProvider1.Clear();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COS_210
{
    public partial class AdminMain : Form
    {
        public AdminMain()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label11_Click(object sender, EventArgs e)  // Log Out Button
        {
            Login log = new Login();
            this.Hide();
            log.Show();
        }

        private void button1_Click(object sender, EventArgs e)  // Member Button
        {
            memberview log = new memberview();
            log.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e) // Trainer Button
        {
            trainerview log = new trainerview();
            this.Hide();
            log.Show();
        }

        private void button4_Click(object sender, EventArgs e) // Payment Button
        {
            payment pay = new payment();
            pay.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e) // Class Button
        {
            cmange log = new cmange();
            this.Hide();
            log.Show();
            
        }

        private void button3_Click(object sender, EventArgs e) // Enrollment Button
        {
            enrollad enroll = new enrollad();
            this.Hide();
            enroll.Show();
        }

        private void button6_Click(object sender, EventArgs e) // Admin Button
        {
            adminview log = new adminview();
            this.Hide();
            log.Show();
        }

        private void AdminMain_Load(object sender, EventArgs e)
        {

        }
    }
}

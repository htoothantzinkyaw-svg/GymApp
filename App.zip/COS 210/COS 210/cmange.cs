﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace COS_210
{
    public partial class cmange : Form
    {
        public cmange()
        {
            InitializeComponent();
        }
        private void fillname() // fill existing trainer name in combo box
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select Tname from trainerTable", con);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("Tname", typeof(string));
            dt.Load(dr);
            ctrainers.ValueMember = "Tname";
            ctrainers.DataSource = dt;
            con.Close();
        }

        private void label11_Click(object sender, EventArgs e) // back button
        {
            AdminMain log = new AdminMain();
            this.Hide();
            log.Show();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\htoot\OneDrive\Documents\Gymdb.mdf;Integrated Security=True;Connect Timeout=30");

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void classid() // Search by class category
        {
            con.Open();
            string query = "select * from classTable where ccategory='" + searchclassid.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            classDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void classdata() // Connect Data Grid View with classTable
        {
            con.Open();
            string query = "select * from classTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            classDG.DataSource = ds.Tables[0];
            con.Close();
        }

        private void button5_Click(object sender, EventArgs e) // Add Class
        {
            if (cid.Text == ""||ccat.Text==""||csession.Text==""||ctrainers.Text=="")
            {
                MessageBox.Show("Please Fill All the Boxes");


            }
            else
            {
                try
                {
                    con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter("select count(*) from classTable where ctrainer ='" + ctrainers.SelectedValue.ToString() + "'", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    string query = "insert into classTable values ('" + cid.Text + "','" + ccat.SelectedItem.ToString() + "','" + csession.SelectedItem.ToString() + "','" + ctrainers.SelectedValue.ToString() + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Class Added Successfully");
                    cid.Text = "";
                    ccat.Text = "";
                    csession.Text = "";
                    ctrainers.Text = "";
   
                    con.Close();
                    classdata();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void cmange_Load(object sender, EventArgs e)
        {
            fillname();
            classdata();
        }
        int key = 0;

        private void classDG_CellContentClick(object sender, DataGridViewCellEventArgs e) // Click cell auto insert values
        {
            key = Convert.ToInt32(classDG.SelectedRows[0].Cells[0].Value.ToString());
            cid.Text = classDG.SelectedRows[0].Cells[1].Value.ToString();
            ccat.Text = classDG.SelectedRows[0].Cells[2].Value.ToString();
            csession.Text = classDG.SelectedRows[0].Cells[3].Value.ToString();
            ctrainers.Text = classDG.SelectedRows[0].Cells[4].Value.ToString();

        }

        private void button3_Click(object sender, EventArgs e)// Clear button
        {
            cid.Text = "";
            ccat.Text = "";
            csession.Text = "";
            ctrainers.Text = "";
        }

        private void label8_Click(object sender, EventArgs e) // Refresh button
        {
            classdata();
        }

        private void button1_Click(object sender, EventArgs e) // Update Button
        {
            if (key == 0 || cid.Text == "" )
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter("select count(*) from classTable where ctrainer ='" + ctrainers.SelectedValue.ToString() + "'", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    string query = "update classTable set Classid='" + cid.Text + "',ccategory='" + ccat.Text + "',csession='" +csession.Text + "',ctrainer='" + ctrainers.Text + "' where cid=" + key + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Class Updated");
                    cid.Text = "";
                    ccat.Text = "";
                    csession.Text = "";
                    ctrainers.Text = "";
                    con.Close();
                    classdata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e) // Delete Button
        {
            if (key == 0)
            {
                MessageBox.Show("Select Class to Delete");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from classTable where cid = " + key + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Class Deleted");
                    cid.Text = "";
                    ccat.Text = "";
                    csession.Text = "";
                    ctrainers.Text = "";
                    con.Close();
                    classdata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e) // Search Button
        {
            classid();
            searchclassid.Text = "";
        }


        private void ctrainers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void searchclassid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

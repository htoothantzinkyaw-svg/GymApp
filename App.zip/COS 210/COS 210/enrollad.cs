﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COS_210
{
    public partial class enrollad : Form
    {
        public enrollad()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e) // Back Button
        {
            AdminMain log = new AdminMain();
            this.Hide();
            log.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        int key = 0;
        private void memberDG_CellContentClick(object sender, DataGridViewCellEventArgs e) // Click Cell auto insert Values
        {
            key = Convert.ToInt32(eDG.SelectedRows[0].Cells[0].Value.ToString());
            eid.Text = eDG.SelectedRows[0].Cells[1].Value.ToString();
            ename.Text = eDG.SelectedRows[0].Cells[2].Value.ToString();
        }
        private void enrolldata() // Conncect Data Grid View and enrollTable
        {
            con.Open();
            string query = "select * from enrollTable ";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            eDG.DataSource = ds.Tables[0];
            con.Close();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\htoot\OneDrive\Documents\Gymdb.mdf;Integrated Security=True;Connect Timeout=30");
        private void enrollad_Load(object sender, EventArgs e)
        {
            enrolldata();
        }
        private void filterbyname() // Search by Member name
        {
            con.Open();
            string query = "select * from enrollTable where ename='" + search.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            eDG.DataSource = ds.Tables[0];
            con.Close();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            enrolldata();
        }

        private void button1_Click(object sender, EventArgs e) // Update Button
        {
            if (key == 0 || ename.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update enrollTable set ename='" + ename.Text + "',enrollclassid='" + eid.Text + "' where eid=" + key + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Enrollment Updated");
                    con.Close();
                    enrolldata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e) // Search button
        {
            filterbyname();
            search.Text = "";
        }

        private void button3_Click(object sender, EventArgs e) // Clear Button
        {
            ename.Text = "";
            eid.Text = "";
        }

        private void button2_Click(object sender, EventArgs e) // Delete Button
        {
            if (key == 0)
            {
                MessageBox.Show("Select Enrolled Class to Delete");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from enrollTable where eid = " + key + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Enrolled Class Deleted");
                    ename.Text = "";
                    eid.Text = "";

                    con.Close();
                    enrolldata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void search_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COS_210
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // X button on the top right coner

            Application.Exit();

        }

        // Connect to Database
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\htoot\OneDrive\Documents\Gymdb.mdf;Integrated Security=True;Connect Timeout=30");

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Sign Up to Member Register

            MemberRegi log = new MemberRegi();
            log.Show();
            this.Hide();

        }

        private void label5_Click(object sender, EventArgs e)
        {
            // Clear Button

            roleCB.Text = "Select Role";
            user.Text = "";
            password.Text = "";

        }

        private void button1_Click(object sender, EventArgs e) // Login Button
        {
            try
            {
                if (user.Text == "" || password.Text == "") // If User doesn't fill Username and Password
                {
                    MessageBox.Show("Enter User and Password");
                }
                else
                {
                    if (roleCB.SelectedIndex > -1)
                    {
                        if (roleCB.SelectedItem.ToString() == "Admin") // Login as Admin
                        {

                            con.Open();
                            SqlDataAdapter sda = new SqlDataAdapter("select count(*) from adminTable where aname='" + user.Text + "' and apw ='" + password.Text + "'", con);
                            DataTable dt = new DataTable();
                            sda.Fill(dt);
                            if (dt.Rows[0][0].ToString() == "1")
                            {
                                MessageBox.Show("Login As Admin");
                                // Go To Admin Form
                                AdminMain ad = new AdminMain();
                                ad.Show();
                                this.Hide();
                                con.Close();
                            }
                            else
                            {
                                MessageBox.Show("Wrong User or Password"); // If inserted admin name and password are not in admin table
                            }
                            con.Close();
                        }
                        else if (roleCB.SelectedItem.ToString() == "Member") // Login as Member
                        {

                            con.Open();
                            SqlDataAdapter sda = new SqlDataAdapter("select count(*) from memberTable where Mname='" + user.Text + "' and Mpw ='" + password.Text + "'", con);
                            DataTable dt = new DataTable();
                            sda.Fill(dt);
                            if (dt.Rows[0][0].ToString() == "1")
                            {
                                MessageBox.Show("Login As Member");
                                // Go To User Form
                                UserMain user = new UserMain();
                                user.Show();
                                this.Hide();
                                con.Close();
                            }
                            else
                            {
                              MessageBox.Show("Wrong User or Password"); // If inserted member name and password are not in member table
                            }
                            con.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Select A Role"); // If User doesn't select Role from combo box
                    }

                }
            }
            catch (Exception ex) // Exception Handler
            {
                MessageBox.Show(ex.Message);
            }    
        }

        private void roleCB_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) // Check box for Show Password
        {
            if(check.Checked)
            {
                password.UseSystemPasswordChar = true;
            }
            else
            {
                password.UseSystemPasswordChar = false; 
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

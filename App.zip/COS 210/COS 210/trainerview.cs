﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace COS_210
{
    public partial class trainerview : Form
    {
        public trainerview()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e) // Back Button
        {
            AdminMain log = new AdminMain();
            this.Hide();
            log.Show();
        }

        private void label1_Click(object sender, EventArgs e) // X button
        {
            Application.Exit();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\htoot\OneDrive\Documents\Gymdb.mdf;Integrated Security=True;Connect Timeout=30");
        Regex ph = new Regex(@"^[0-9]+$");
        
        private void trainerview_Load(object sender, EventArgs e)
        {
            trainerdata();
        }
        private void filterbyname() // search by trainer name
        {
            con.Open();
            string query = "select * from trainerTable where Tname='" + searchtname.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            trainerDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void trainerdata() // connect Data Grid View with trainerTable
        {
            con.Open();
            string query = "select * from trainerTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            trainerDG.DataSource = ds.Tables[0];
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e) // search button
        {
            filterbyname();
            searchtname.Text = "";
        }

        private void label8_Click(object sender, EventArgs e) // Refresh button
        {
            trainerdata();
        }

        private void button3_Click(object sender, EventArgs e) // Clear button
        {
            tname.Text = "";
            tgender.Text = "Select Gender";
            tphno.Text = "";
            tfee.Text = "";
        }
        int key = 0;

        private void trainerDG_CellContentClick(object sender, DataGridViewCellEventArgs e) // Cellclick auto insert values
        {
            key = Convert.ToInt32(trainerDG.SelectedRows[0].Cells[0].Value.ToString());
            tname.Text = trainerDG.SelectedRows[0].Cells[1].Value.ToString();
            tgender.Text = trainerDG.SelectedRows[0].Cells[2].Value.ToString();
            tphno.Text = trainerDG.SelectedRows[0].Cells[3].Value.ToString();
            tfee.Text = trainerDG.SelectedRows[0].Cells[4].Value.ToString();
        }
        

        private void button2_Click(object sender, EventArgs e) // Delet Button
        {
            if (key == 0)
            {
                MessageBox.Show("Select Trainer to Delete");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from trainerTable where Tid = " + key + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Trainer Deleted");
                    tname.Text = "";
                    tgender.Text = "Select Gender";
                    tphno.Text = "";
                    tfee.Text = "";
                    con.Close();
                    trainerdata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e) // Update Button
        {

            if (key == 0 || tname.Text == "" ||  tphno.Text == "" || tfee.Text == "" )
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update trainerTable set Tname='" + tname.Text + "',Tgen='" + tgender.Text + "',Tph='" + tphno.Text + "',Tsalary='" + tfee.Text + "' where Tid=" + key + ";";
                    if (!ph.IsMatch(tphno.Text))
                    {
                        MessageBox.Show(this.tphno, " No Letters in Ph No !!!");
                    }
                    else if (tphno.TextLength < 10)
                    {
                        MessageBox.Show(this.tphno, "At Least 10 digits in Ph No");
                    }
                    else if (!ph.IsMatch(tfee.Text))
                    {
                        MessageBox.Show(this.tfee, "No Letters in Salary!!!");
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Trainer Updated");
                    }
                    con.Close();
                    trainerdata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e) // Add Button
        {
            if (tname.Text == "" ||  tphno.Text == "" || tfee.Text == "" )
            {
                MessageBox.Show("Please Fill All the Boxes");


            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into trainerTable values ('" + tname.Text + "','" + tgender.SelectedItem.ToString() + "','" + tphno.Text + "','" + tfee.Text + "')";
                    if (!ph.IsMatch(tphno.Text))
                    {
                        MessageBox.Show(this.tphno, " No Letters in Ph No !!!");
                    }
                    else if(tphno.TextLength < 10)
                    {
                        MessageBox.Show(this.tphno, "At Least 10 digits in Ph No");
                    }
                    else if (!ph.IsMatch(tfee.Text))
                    {
                        MessageBox.Show(this.tfee, "No Letters in Salary!!!");
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Trainer Added Successfully");
                    }
                    con.Close();
                    trainerdata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }


        // Error Provider Codes
        private void tphno_TextChanged(object sender, EventArgs e)
        {
            if (ph.IsMatch(tphno.Text))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.tphno, " No Letters!!!");
            }
        }

        private void tfee_TextChanged(object sender, EventArgs e)
        {
            if (ph.IsMatch(tfee.Text))
            {
                errorProvider2.Clear();
            }
            else
            {
                errorProvider2.SetError(this.tfee, " No Letters!!!");
            }
        }
    }
}

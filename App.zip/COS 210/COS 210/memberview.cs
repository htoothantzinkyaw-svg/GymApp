﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COS_210
{
    public partial class memberview : Form
    {
        public memberview()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            AdminMain log = new AdminMain();
            this.Hide();
            log.Show();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\htoot\OneDrive\Documents\Gymdb.mdf;Integrated Security=True;Connect Timeout=30");
        private void filterbyname() // search by member name
        {
            con.Open();
            string query = "select * from memberTable where Mname='" + searchmname.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            memberDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void memberdata() // Conncet the Data Grid View and memberTable
        {
            con.Open();
            string query = "select * from memberTable";
            SqlDataAdapter sda =new SqlDataAdapter(query,con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            memberDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void memberview_Load(object sender, EventArgs e)
        {
            memberdata();
        }

        private void button3_Click(object sender, EventArgs e) // Clear Button
        {
            Mname.Text = "";
            Mgender.Text = "";
            Mage.Text = "";
            Mphno.Text = "";
            Msession.Text = "";
            Mfee.Text = "";
            Mgmail.Text = "";
        }
        int key = 0;
        private void memberDG_CellContentClick(object sender, DataGridViewCellEventArgs e) // Click the data grid view cells to auto insert the values
        {
            key = Convert.ToInt32(memberDG.SelectedRows[0].Cells[0].Value.ToString());
            Mname.Text = memberDG.SelectedRows[0].Cells[1].Value.ToString();
            Mgender.Text = memberDG.SelectedRows[0].Cells[2].Value.ToString();
            Mage.Text = memberDG.SelectedRows[0].Cells[3].Value.ToString();
            Mphno.Text = memberDG.SelectedRows[0].Cells[4].Value.ToString();
            Msession.Text = memberDG.SelectedRows[0].Cells[5].Value.ToString();
            Mfee.Text = memberDG.SelectedRows[0].Cells[6].Value.ToString();
            Mgmail.Text = memberDG.SelectedRows[0].Cells[8].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e) // delete Button
        {
            if(key==0)
            {
                MessageBox.Show("Select Member to Delete");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from memberTable where Mid = " + key + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Member Deleted");
                    Mname.Text = "";
                    Mgender.Text = "";
                    Mage.Text = "";
                    Mphno.Text = "";
                    Msession.Text = "";
                    Mfee.Text = "";
                    Mgmail.Text = "";
                    con.Close();
                    memberdata();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);    
                }
            }
        }
        Regex ph = new Regex(@"^[0-9]+$");
        string email = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";

        private void button1_Click(object sender, EventArgs e) // Update Buttone
        {
            if (key == 0|| Mname.Text ==""|| Mage.Text==""|| Mphno.Text==""||Msession.Text==""||Mfee.Text==""||Mgmail.Text=="")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update memberTable set Mname='"+Mname.Text+"',Mgender='"+Mgender.Text+"',Mage='"+Mage.Text +"',Mphno='"+Mphno.Text +"',Msession='"+Msession.Text + "',Mfee='"+Mfee.Text + "',Mgmail='"+Mgmail.Text +"' where Mid="+key+";";

                    if (Mphno.TextLength < 10)
                    {
                        MessageBox.Show(this.Mphno, "At least 10 Digits in Ph.No ");
                    }
                    else if (!ph.IsMatch(Mphno.Text))
                    {
                        MessageBox.Show(this.Mphno, "Why are you adding Letters in Ph.No?");
                    }
                    else if (!ph.IsMatch(Mage.Text))
                    {
                        MessageBox.Show(this.Mage, " Seriously !? NO LETTERS IN AGE !!!");
                    }
                    else if (Mage.TextLength >= 3)
                    {
                        MessageBox.Show(this.Mage, " Why did I choose this human who add 3 digits in Age as An ADMIN ? ");
                    }
                    else if (!ph.IsMatch(Mfee.Text))
                    {
                        MessageBox.Show(this.Mfee, " Why are you adding Letters in Fee agian ? ");
                    }
                    else if (!Regex.IsMatch(Mgmail.Text, email))
                    {
                        MessageBox.Show(this.Mgmail, " PLEASE!! Just please add a valid email ");
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Member Updated");
                    }
                    con.Close();
                    memberdata();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void button4_Click(object sender, EventArgs e) // Search Button
        {
            filterbyname();
            searchmname.Text = "";
        }

        private void label8_Click(object sender, EventArgs e)
        {
            memberdata();
        }

        private void searchmname_TextChanged(object sender, EventArgs e)
        {

        }

        // Error Provider Codes
        private void Mgmail_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(Mgmail.Text, email))
            {
                errorProvider4.Clear();
            }
            else
            {
                errorProvider4.SetError(this.Mgmail, "Invalid Email Format !!!");

            }
        }

        private void Mfee_TextChanged(object sender, EventArgs e)
        {
            if (ph.IsMatch(Mfee.Text))
            {
                errorProvider3.Clear();
            }
            else
            {
                errorProvider3.SetError(this.Mfee, " No Letters !!!");
            }
        }

        private void Mphno_TextChanged(object sender, EventArgs e)
        {
            if (ph.IsMatch(Mphno.Text))
            {
                errorProvider2.Clear();
            }
            else
            {
                errorProvider2.SetError(this.Mphno, " No Letters!!!");
            }
        }

        private void Mage_TextChanged(object sender, EventArgs e)
        {
            if (ph.IsMatch(Mage.Text))
            {
                errorProvider1.Clear();
            }
            else 
            {
                errorProvider1.SetError(this.Mage, " No Letters !!! ");
            }
           
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COS_210
{
    public partial class payment : Form
    {
        public payment()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\htoot\OneDrive\Documents\Gymdb.mdf;Integrated Security=True;Connect Timeout=30");
        Regex ph = new Regex(@"^[0-9]+$");
        private void fillname() // Fill member names from memberTable into combo box
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select Mname from memberTable", con);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("Mname", typeof(string));
            dt.Load(dr);
            MName.ValueMember = "Mname";
            MName.DataSource = dt;
            con.Close();
        }
        private void button2_Click(object sender, EventArgs e) // Clear
        {
            MName.Text = "";
            MFee.Text = "";
        }

        private void label11_Click(object sender, EventArgs e) // Back Button
        {
            AdminMain log = new AdminMain();
            this.Hide();
            log.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void payment_Load(object sender, EventArgs e)
        {
            fillname();
            paydata();
        }

        private void filterbyname() // Search by name
        {
            con.Open();
            string query = "select * from payTable where Pmember='" +searchp.Text+ "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            PaymentDG.DataSource = ds.Tables[0];
            con.Close();
        }
        private void paydata()
        {
            con.Open();
            string query = "select * from payTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            PaymentDG.DataSource = ds.Tables[0];
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(MName.Text == "" || MFee.Text =="")
            {
                MessageBox.Show("Missing Info");
            }
            else
            {
                try
                {

                    string paytime = Date.Value.Month.ToString() + "/" + Date.Value.Year.ToString();
                    con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter("select count(*) from payTable where Pmember ='" + MName.SelectedValue.ToString() + "'and Pmonth='" + paytime + "'", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows[0][0].ToString() == "1") // pay validation
                    {
                        MessageBox.Show("Already Paid for this Month"); 
                    }
                    else
                    {

                        string query = "insert into payTable values('" + paytime + "','" + MName.SelectedValue.ToString() + "'," + MFee.Text + ")";
                        if (!ph.IsMatch(MFee.Text))
                        {
                            errorProvider1.SetError(this.MFee, " No Letters Allowed!!!"); // Fee Validation
                        }
                        else
                        {
                            SqlCommand cmd = new SqlCommand(query, con);
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Paid Successfully");
                            con.Close();
                            paydata();
                        }
                      
                    }
                    con.Close();
                    paydata();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e) // Search Button
        {
            filterbyname();
            searchp.Text = "";
        }

        private void label8_Click(object sender, EventArgs e)
        {
            paydata();  
        }

        private void searchname_TextChanged(object sender, EventArgs e)
        {
     
        
        }

        private void MName_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void searchp_TextChanged(object sender, EventArgs e)
        {

        }

        private void MFee_TextChanged(object sender, EventArgs e) // Fee Validation
        {
            if (ph.IsMatch(MFee.Text))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.MFee, " No Letters Allowed !!!");
            }
        }
    }
}
